package com.example.group.handler;

import com.example.group.exception.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // 400 – 잘못된 상태값 (enum 역직렬화 실패 or 직접 throw)
    @ExceptionHandler({
            InvalidGroupStateException.class,
            HttpMessageNotReadableException.class,   // Jackson이 던지는 역직렬화 오류
            IllegalArgumentException.class
    })
    public ResponseEntity<Map<String, Object>> handleBadRequest(Exception e) {
        return error(HttpStatus.BAD_REQUEST, e.getMessage());
    }

    // 403 – 그룹장이 아님
    @ExceptionHandler(NotGroupLeaderException.class)
    public ResponseEntity<Map<String, Object>> handleForbidden(NotGroupLeaderException e) {
        return error(HttpStatus.FORBIDDEN, e.getMessage());
    }

    // 404 – 그룹 없음
    @ExceptionHandler(GroupNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFound(GroupNotFoundException e) {
        return error(HttpStatus.NOT_FOUND, e.getMessage());
    }

    // 409 – 상태 변경 불가
    @ExceptionHandler(GroupStateConflictException.class)
    public ResponseEntity<Map<String, Object>> handleConflict(GroupStateConflictException e) {
        return error(HttpStatus.CONFLICT, e.getMessage());
    }

    // ── 공통 에러 응답 포맷 ────────────────────────────────
    private ResponseEntity<Map<String, Object>> error(HttpStatus status, String message) {
        return ResponseEntity.status(status).body(Map.of(
                "status", status.value(),
                "error", status.getReasonPhrase(),
                "message", message != null ? message : "",
                "timestamp", Instant.now().toString()
        ));
    }
}
