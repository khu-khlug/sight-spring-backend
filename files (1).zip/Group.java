package com.example.group.domain;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class Group {

    private final Long groupId;
    private final Long leaderId;   // 그룹장 ID
    private GroupState state;

    public boolean isLeader(Long userId) {
        return this.leaderId.equals(userId);
    }

    public boolean isTerminal() {
        return this.state.isTerminal();
    }

    public boolean isSameState(GroupState newState) {
        return this.state == newState;
    }

    public GroupState changeState(GroupState newState) {
        this.state = newState;
        return this.state;
    }
}
