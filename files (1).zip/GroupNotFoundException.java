package com.example.group.exception;

// 404 – 그룹 없음
public class GroupNotFoundException extends RuntimeException {
    public GroupNotFoundException(Long groupId) {
        super("그룹을 찾을 수 없습니다. groupId=" + groupId);
    }
}
