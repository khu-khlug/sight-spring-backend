package com.example.group.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.Arrays;

public enum GroupState {

    PROGRESS("progress"),
    SUSPEND("suspend"),
    END_SUCCESS("end-success"),
    END_FAIL("end-fail");

    private final String value;

    GroupState(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    @JsonCreator
    public static GroupState from(String value) {
        if (value == null) {
            throw new IllegalArgumentException("state는 null일 수 없습니다.");
        }
        return Arrays.stream(GroupState.values())
                .filter(s -> s.value.equals(value))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("유효하지 않은 상태값입니다: " + value));
    }

    public boolean isTerminal() {
        return this == END_FAIL;
    }
}
