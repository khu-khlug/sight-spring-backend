package com.example.group.exception;

// 409 – 상태 변경 불가 (end-fail 등 종료 상태)
public class GroupStateConflictException extends RuntimeException {
    public GroupStateConflictException(String message) {
        super(message);
    }
}
