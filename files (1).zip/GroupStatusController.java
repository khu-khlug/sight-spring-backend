package com.example.group.controller;

import com.example.group.dto.GroupStatusDto;
import com.example.group.service.GroupStatusService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/groups")
@RequiredArgsConstructor
public class GroupStatusController {

    private final GroupStatusService groupStatusService;

    /**
     * PATCH /groups/{groupId}/status
     * 그룹 상태 변경
     */
    @PatchMapping("/{groupId}/status")
    public ResponseEntity<GroupStatusDto.Response> changeStatus(
            @PathVariable Long groupId,
            @AuthenticationPrincipal Long requesterId,   // SecurityContext에서 사용자 ID 추출
            @RequestBody GroupStatusDto.Request request) {

        GroupStatusDto.Response response =
                groupStatusService.changeStatus(groupId, requesterId, request);

        return ResponseEntity.ok(response);
    }
}
