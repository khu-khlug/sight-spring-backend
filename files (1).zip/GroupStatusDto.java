package com.example.group.dto;

import com.example.group.domain.GroupState;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.Instant;

// ── 요청 ──────────────────────────────────────────────
public class GroupStatusDto {

    @Getter
    @NoArgsConstructor
    public static class Request {
        private GroupState state;
    }

    // ── 응답 ──────────────────────────────────────────────
    @Getter
    public static class Response {

        private final Long groupId;

        @JsonProperty("prevState")
        private final String prevState;

        private final String currentState;
        private final String changedAt;

        public Response(Long groupId, GroupState prevState, GroupState currentState) {
            this.groupId      = groupId;
            this.prevState    = prevState.getValue();
            this.currentState = currentState.getValue();
            this.changedAt    = Instant.now().toString();   // ISO 8601
        }
    }
}
