package com.example.group.service;

import com.example.group.domain.Group;
import com.example.group.domain.GroupState;
import com.example.group.dto.GroupStatusDto;
import com.example.group.exception.GroupNotFoundException;
import com.example.group.exception.GroupStateConflictException;
import com.example.group.exception.NotGroupLeaderException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class GroupStatusService {

    private final GroupRepository groupRepository;
    private final GroupNotificationService notificationService;

    /**
     * 그룹 상태 변경
     *
     * @param groupId   변경 대상 그룹 ID
     * @param requesterId 요청자(현재 로그인 사용자) ID – 컨트롤러에서 SecurityContext 등으로 주입
     * @param request   요청 바디
     * @return 변경 결과
     */
    @Transactional
    public GroupStatusDto.Response changeStatus(
            Long groupId,
            Long requesterId,
            GroupStatusDto.Request request) {

        // 1. 그룹 조회 (없으면 404)
        Group group = groupRepository.findById(groupId)
                .orElseThrow(() -> new GroupNotFoundException(groupId));

        // 2. 권한 검증 – 그룹장만 변경 가능 (아니면 403)
        if (!group.isLeader(requesterId)) {
            throw new NotGroupLeaderException();
        }

        // 3. 종료 상태(end-fail) 이면 복구 불가 (409)
        if (group.isTerminal()) {
            throw new GroupStateConflictException("end-fail 상태의 그룹은 상태를 변경할 수 없습니다.");
        }

        GroupState newState = request.getState();
        GroupState prevState = group.getState();

        // 4. 동일 상태 요청 → idempotent: 변경 없이 200 반환
        if (group.isSameState(newState)) {
            return new GroupStatusDto.Response(groupId, prevState, prevState);
        }

        // 5. 상태 변경 및 저장
        group.changeState(newState);
        groupRepository.save(group);

        // 6. 그룹 멤버에게 알림 발송
        notificationService.notifyStateChanged(groupId, prevState, newState);

        return new GroupStatusDto.Response(groupId, prevState, newState);
    }
}
