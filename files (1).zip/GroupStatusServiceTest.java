package com.example.group.service;

import com.example.group.domain.Group;
import com.example.group.domain.GroupState;
import com.example.group.dto.GroupStatusDto;
import com.example.group.exception.GroupNotFoundException;
import com.example.group.exception.GroupStateConflictException;
import com.example.group.exception.NotGroupLeaderException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.*;

@ExtendWith(MockitoExtension.class)
class GroupStatusServiceTest {

    @Mock GroupRepository groupRepository;
    @Mock GroupNotificationService notificationService;
    @InjectMocks GroupStatusService groupStatusService;

    private static final Long GROUP_ID   = 1L;
    private static final Long LEADER_ID  = 10L;
    private static final Long MEMBER_ID  = 99L;

    private Group group(GroupState state) {
        return Group.builder()
                .groupId(GROUP_ID)
                .leaderId(LEADER_ID)
                .state(state)
                .build();
    }

    private GroupStatusDto.Request request(GroupState state) {
        // 리플렉션 없이 Jackson ObjectMapper 대신 직접 생성 (필드 접근)
        GroupStatusDto.Request req = new GroupStatusDto.Request();
        // state 필드는 package-private setter나 테스트용 생성자로 주입
        // 여기서는 Mockito spy나 ReflectionTestUtils 활용 가능
        org.springframework.test.util.ReflectionTestUtils.setField(req, "state", state);
        return req;
    }

    // ── TC 1: end-success 상태로 변경 ──────────────────────
    @Test
    @DisplayName("TC-1: state = end-success 이면 성공 상태로 변경된다")
    void changeToEndSuccess() {
        Group g = group(GroupState.PROGRESS);
        given(groupRepository.findById(GROUP_ID)).willReturn(Optional.of(g));
        given(groupRepository.save(any())).willAnswer(inv -> inv.getArgument(0));

        GroupStatusDto.Response response =
                groupStatusService.changeStatus(GROUP_ID, LEADER_ID, request(GroupState.END_SUCCESS));

        assertThat(response.getPrevState()).isEqualTo("progress");
        assertThat(response.getCurrentState()).isEqualTo("end-success");
        then(notificationService).should().notifyStateChanged(GROUP_ID, GroupState.PROGRESS, GroupState.END_SUCCESS);
    }

    // ── TC 2: progress 상태로 변경 ─────────────────────────
    @Test
    @DisplayName("TC-2: state = progress 이면 진행중 상태로 변경된다")
    void changeToProgress() {
        Group g = group(GroupState.SUSPEND);
        given(groupRepository.findById(GROUP_ID)).willReturn(Optional.of(g));
        given(groupRepository.save(any())).willAnswer(inv -> inv.getArgument(0));

        GroupStatusDto.Response response =
                groupStatusService.changeStatus(GROUP_ID, LEADER_ID, request(GroupState.PROGRESS));

        assertThat(response.getCurrentState()).isEqualTo("progress");
    }

    // ── TC 3: suspend 상태로 변경 ──────────────────────────
    @Test
    @DisplayName("TC-3: state = suspend 이면 활동 중단 상태로 변경된다")
    void changeToSuspend() {
        Group g = group(GroupState.PROGRESS);
        given(groupRepository.findById(GROUP_ID)).willReturn(Optional.of(g));
        given(groupRepository.save(any())).willAnswer(inv -> inv.getArgument(0));

        GroupStatusDto.Response response =
                groupStatusService.changeStatus(GROUP_ID, LEADER_ID, request(GroupState.SUSPEND));

        assertThat(response.getCurrentState()).isEqualTo("suspend");
    }

    // ── TC 4: end-fail 상태로 변경 ─────────────────────────
    @Test
    @DisplayName("TC-4: state = end-fail 이면 실패 상태로 변경된다")
    void changeToEndFail() {
        Group g = group(GroupState.PROGRESS);
        given(groupRepository.findById(GROUP_ID)).willReturn(Optional.of(g));
        given(groupRepository.save(any())).willAnswer(inv -> inv.getArgument(0));

        GroupStatusDto.Response response =
                groupStatusService.changeStatus(GROUP_ID, LEADER_ID, request(GroupState.END_FAIL));

        assertThat(response.getCurrentState()).isEqualTo("end-fail");
    }

    // ── TC 5: 잘못된 상태값(NULL) → GroupState.from()에서 IAE ─
    @Test
    @DisplayName("TC-5: state = null 이면 IllegalArgumentException 발생 (→ 400)")
    void nullStateThrows() {
        assertThatThrownBy(() -> GroupState.from(null))
                .isInstanceOf(IllegalArgumentException.class);
    }

    // ── TC 6: 그룹장이 아닌 사용자 → 403 ─────────────────
    @Test
    @DisplayName("TC-6: 그룹장이 아닌 사용자가 요청하면 NotGroupLeaderException (→ 403)")
    void nonLeaderThrowsForbidden() {
        Group g = group(GroupState.PROGRESS);
        given(groupRepository.findById(GROUP_ID)).willReturn(Optional.of(g));

        assertThatThrownBy(() ->
                groupStatusService.changeStatus(GROUP_ID, MEMBER_ID, request(GroupState.END_SUCCESS)))
                .isInstanceOf(NotGroupLeaderException.class);
    }

    // ── TC 7: 존재하지 않는 groupId → 404 ─────────────────
    @Test
    @DisplayName("TC-7: 존재하지 않는 groupId 이면 GroupNotFoundException (→ 404)")
    void groupNotFound() {
        given(groupRepository.findById(GROUP_ID)).willReturn(Optional.empty());

        assertThatThrownBy(() ->
                groupStatusService.changeStatus(GROUP_ID, LEADER_ID, request(GroupState.PROGRESS)))
                .isInstanceOf(GroupNotFoundException.class);
    }

    // ── TC 8: 동일 상태 요청 → 변경 없이 200 ─────────────
    @Test
    @DisplayName("TC-8: 동일 상태 요청이면 변경 없이 현재 상태를 그대로 반환한다")
    void sameStateIsIdempotent() {
        Group g = group(GroupState.PROGRESS);
        given(groupRepository.findById(GROUP_ID)).willReturn(Optional.of(g));

        GroupStatusDto.Response response =
                groupStatusService.changeStatus(GROUP_ID, LEADER_ID, request(GroupState.PROGRESS));

        assertThat(response.getPrevState()).isEqualTo(response.getCurrentState());
        then(groupRepository).should(never()).save(any());
        then(notificationService).should(never()).notifyStateChanged(any(), any(), any());
    }

    // ── TC 9: end-fail 상태에서 변경 시도 → 409 ───────────
    @Test
    @DisplayName("TC-9: end-fail 상태에서 상태 변경 요청 시 GroupStateConflictException (→ 409)")
    void endFailIsTerminal() {
        Group g = group(GroupState.END_FAIL);
        given(groupRepository.findById(GROUP_ID)).willReturn(Optional.of(g));

        assertThatThrownBy(() ->
                groupStatusService.changeStatus(GROUP_ID, LEADER_ID, request(GroupState.PROGRESS)))
                .isInstanceOf(GroupStateConflictException.class);
    }
}
