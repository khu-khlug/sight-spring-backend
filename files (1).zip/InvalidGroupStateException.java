package com.example.group.exception;

// 400 – 잘못된 상태값 (JsonCreator에서 던지는 IAE를 래핑하거나 직접 사용)
public class InvalidGroupStateException extends RuntimeException {
    public InvalidGroupStateException(String message) {
        super(message);
    }
}
