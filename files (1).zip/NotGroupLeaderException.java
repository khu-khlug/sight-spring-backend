package com.example.group.exception;

// 403 – 그룹장이 아님
public class NotGroupLeaderException extends RuntimeException {
    public NotGroupLeaderException() {
        super("그룹장만 상태를 변경할 수 있습니다.");
    }
}
